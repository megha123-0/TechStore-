const TechStoreApp = (() => {//IIFE closure
  const API_URL = "https://dummyjson.com/products";
  let products = [];
  const fetchProducts = async () => {//Fetch API with async
    try {
      const response = await fetch(API_URL);
      const data = await response.json();
      return data.products;
    } catch (error) {
      console.error(error);
      return [];
    }
  };
  const renderTable = () => {// rendering product table Dom
    const tbody = document.getElementById("product-body");
    tbody.innerHTML = "";
    products.forEach(product => {
      tbody.innerHTML += `
        <tr>
          <td><img src="${product.thumbnail}" width="50"></td>
          <td>${product.title}</td>
          <td>$${product.price}</td>
          <td>${product.category}</td>
          <td>${product.stock}</td>
          <td>
            <button class="delete-btn" data-id="${product.id}">Delete</button>
          </td>
        </tr>
      `;
    });
    updateStats();
  };
const updateStats = () => { // statistics calculations
  document.getElementById("total-products").textContent = products.length;//Total products
  const totalValue = products.reduce((sum, p) => sum + p.price * p.stock,0);//Total inventory Value
  document.getElementById("total-value").textContent = totalValue.toFixed(2);
  const lowStockCount = products.filter(p => p.stock < 10).length; // LOW STOCK (stock < 10)
  document.getElementById("low-stock").textContent = lowStockCount;
  const categories = [...new Set(products.map(p => p.category))];  // CATEGORIES COUNT
  document.getElementById("categories-count").textContent = categories.length;
};
  const handleAddProduct = () => { //Adding new products
    const form = document.getElementById("product-form");

    form.addEventListener("submit", (e) => {
      e.preventDefault();

      const newProduct = {
        id: Date.now(),
        title: document.getElementById("name").value,
        price: Number(document.getElementById("price").value),
        category: document.getElementById("category").value,
        stock: Number(document.getElementById("stock").value),
        thumbnail: "https://via.placeholder.com/50"
      };

      products.push(newProduct);
      localStorage.setItem("products", JSON.stringify(products));
      renderTable();
      form.reset();
    });
  };

  const handleDeleteProduct = () => { //Deleting Products(Event Delegation)
    document.getElementById("product-body")
      .addEventListener("click", (e) => {
        if (e.target.classList.contains("delete-btn")) {
          const id = Number(e.target.dataset.id);
          products = products.filter(p => p.id !== id);
          localStorage.setItem("products", JSON.stringify(products));
          renderTable();
        }
      });
  };
const init = async () => {
  const stored = localStorage.getItem("products");
  if (stored) {
    products = JSON.parse(stored);
  } else {
    products = await fetchProducts();
    localStorage.setItem("products", JSON.stringify(products));
  }
  renderTable();
  handleAddProduct();
  handleDeleteProduct();
  handleButtons(); 
};
const handleButtons = () => {
  document.getElementById("refresh-btn").addEventListener("click", async () => {
    products = await fetchProducts();
    localStorage.setItem("products", JSON.stringify(products));
    renderTable();
  });
  document.getElementById("clear-btn").addEventListener("click", () => {
    localStorage.clear();
    products = [];
    renderTable();
  });
};
  return { init };
})();
document.addEventListener("DOMContentLoaded", () => {
  TechStoreApp.init();
});
